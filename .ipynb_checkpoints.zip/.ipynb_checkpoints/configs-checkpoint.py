save_dir                    = '/workspace/Shantan_Data/Bayesian2v/save/'
data_dir = {}
data_dir['Casting']         = '/workspace/Shantan_Data/Bayesian2v/Casting/'
data_dir['SS']              = '/workspace/Shantan_Data/Bayesian2v/Steel_Surface/dataset/'
data_dir['auto1']           = '/workspace/Shantan_Data/Bayesian2v/Auto1/Bayesian_data/'
data_dir['auto']            = '/workspace/Shantan_Data/Bayesian2v/Auto2/'
data_dir['Mask']            = '/workspace/Shantan_Data/Bayesian2v/filelists/Mask/'
data_dir['miniimagenet']    = '/workspace/Shantan_Data/Bayesian2v/filelists/miniimagenet/'
data_dir['omniglot']        = '/workspace/Shantan_Data/Bayesian2v/filelists/omniglot/'
data_dir['emnist']          = '/workspace/Shantan_Data/Bayesian2v/filelists/emnist/'
data_dir['CUB']             = '/workspace/Shantan_Data/Bayesian2v/filelists/CUB/'

kernel_type                 = 'linear' #linear, rbf, spectral (regression only), matern, poli1, poli2, cossim, bncossim 
